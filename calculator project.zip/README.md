# Calculator_Project

In this project, I build a basic calculator using HTML , CSS & JavaScript. HTML gives the basic structure of calc, CSS defines the styling & Javascript is used to add functionality of addition, substraction, multiplication, division, etc.
